"use client";
import React from "react";

type Props = {};

export default function articles({}: Props) {
  return <div>articles</div>;
}
