"use client";
import React from "react";

type Props = {};

export default function categories({}: Props) {
  return <div>page</div>;
}
